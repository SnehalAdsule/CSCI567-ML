import bias_variance
import libsvm

print 'CSCI 567 HW3 '